<?php
$conn_link= mysqli_connect("localhost","root","","college");

?>